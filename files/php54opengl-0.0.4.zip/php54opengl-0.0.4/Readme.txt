    OpenGL/GLUT for PHP5.4 exe tarball v0.0.4
    and OpenAL/ALUT v0.0.3y2
                                           2013/2/13 yoya@awm.jp

copyright:
 - originated by colinrgodsey@users.sourceforge.net (OpenGL)
 - modified by yoya@awm.jp (PHP5 migration and little customize)
 - originated by pollita@php.net (OpenAL)
 - modified by yoya@awm.jp (Windows Build)

build env:
 - Microsoft Windows 7
 - Microsoft Visual C++ 2008 Express
 - Microsoft Windows SDK v6.1
 - GLUT 3.7.6 (http://www.xmission.com/~nate/glut.html)
 - OpenAL11CoreSDK.zip (http://connect.creativelabs.com/openal)
 - freealut-1.1.0-bin.zip

test env:
 - Microsoft Windows 7
 - OpenAL11CoreSDK.zip (http://connect.creativelabs.com/openal)

code repos: 
 - http://phpopengl.sourceforge.net/  (PHP4)
 - https://github.com/yoya/phpopengl/ (PHP5)
 - http://pecl.php.net/package/openal (UNIX)
 - https://github.com/yoya/phpopenal/ (config.w32)

sorry:
 - OpenGL support only v1.2
   I shall support greater version API.
 - msvcm90.dll
   I'm trying embeded to exe file.

changelog:
 - v0.0.4: efree after glFlush
 - v0.0.3: fixed to glutTimerFunc
 - v0.0.2: callback function began to be stable.
 - v0.0.1: first release - unstable.
